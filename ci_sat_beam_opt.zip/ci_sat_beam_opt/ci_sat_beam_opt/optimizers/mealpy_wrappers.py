import numpy as np
from mealpy import evolutionary, swarm

def _decode_candidate(x, N, amp_levels, amp_codebook, phase_bits):
    """
    Decode real genes in [0,1) to complex weights with quantized phase and optional amplitude index.
    """
    B = phase_bits
    L = amp_levels
    x = np.asarray(x)
    ptr = 0
    phase_codes = (x[ptr:ptr+N] * (2**B)).astype(int) % (2**B); ptr += N
    if L > 1:
        amp_codes = (x[ptr:ptr+N] * L).astype(int) % L; ptr += N
        amp = amp_codebook[amp_codes]
    else:
        amp = np.ones(N)
    phases = phase_codes * (2*np.pi/(2**B))
    w = amp * np.exp(1j*phases)
    return w

def make_fitness(array, T, az_series, el_series, forbidden_dirs, alpha, beta, gamma,
                 noise_power_dbm, interferers, interferer_lin_power,
                 apply_errors, retune_weight=True):
    """
    Build a Mealpy-compatible fitness function minimizing the negative aggregate objective.
    """
    N = array.N
    B = array.phase_bits
    L = array.amp_levels
    amp_codebook = array.amp_codebook
    genome_len_per_t = N*(1 + (1 if L>1 else 0))

    def f(x):
        x = np.asarray(x)
        assert x.size == genome_len_per_t*T
        weights_series = []
        ptr = 0
        for _ in range(T):
            genes = x[ptr:ptr+genome_len_per_t]
            w = _decode_candidate(genes, N, L, amp_codebook, B)
            w = w.copy()
            w[array.failed] = 0.0
            weights_series.append(w)
            ptr += genome_len_per_t

        from ..objectives import snr_time_series, sidelobe_metric, retune_cost, aggregate_objective
        snr_series = snr_time_series(array, az_series, el_series, weights_series,
                                     noise_power_dbm=noise_power_dbm,
                                     interferers=interferers,
                                     interferer_lin_power=interferer_lin_power,
                                     apply_errors=apply_errors)
        sll_series = [sidelobe_metric(array, w, forbidden_dirs, apply_errors=False) for w in weights_series]
        rcost = retune_cost(weights_series) if retune_weight else 0.0
        obj, _, _ = aggregate_objective(snr_series, sll_series, rcost, alpha=alpha, beta=beta, gamma=gamma)
        return -obj

    return f

def run_mealpy(optimizer_name, fitness, lb, ub, dims, pop=32, iters=100, seed=42):
    """
    Run a selected Mealpy optimizer (GA/DE/PSO).
    """
    problem = {"fit_func": fitness, "lb": lb, "ub": ub, "minmax": "min", "name": "BeamOpt", "log_to": None}
    name = optimizer_name.upper()
    if name == "GA":
        Model = evolutionary.GA.BaseGA
        opt = Model(problem, epoch=iters, pop_size=pop, pc=0.9, pm=0.02, seed=seed)
    elif name == "DE":
        Model = evolutionary.DE.BaseDE
        opt = Model(problem, epoch=iters, pop_size=pop, wf=0.8, cr=0.9, seed=seed)
    elif name == "PSO":
        Model = swarm.PSO.BasePSO
        opt = Model(problem, epoch=iters, pop_size=pop, c1=1.8, c2=1.8, wmin=0.2, wmax=0.9, seed=seed)
    else:
        raise ValueError("Unknown optimizer: " + optimizer_name)
    g_best = opt.train()
    return opt, g_best
